#pragma once
#include "RendererInterface.h"

class MeshRenderer : public IRenderer
{

};
