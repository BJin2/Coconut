#pragma once
#include "UIInterface.h"

class Text : public IUI
{

};
