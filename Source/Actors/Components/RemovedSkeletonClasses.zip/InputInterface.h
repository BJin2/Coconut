#pragma once
#include "ActorComponent.h"

class IInput : public ActorComponent
{

};
