#pragma once
#include "InputInterface.h"

class PlayerController : IInput
{

};
