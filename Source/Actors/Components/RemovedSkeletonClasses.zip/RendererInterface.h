#pragma once
#include "ActorComponent.h"

class IRenderer : public ActorComponent
{

};
