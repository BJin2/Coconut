#pragma once
#include "UIInterface.h"

class Sprite : public IUI
{

};