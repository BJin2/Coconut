#pragma once
#include "Collider.h"

class CapsuleCollider : public Collider
{

};
