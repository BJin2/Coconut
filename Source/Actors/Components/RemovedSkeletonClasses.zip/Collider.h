#pragma once
#include "PhysicsComponentInterface.h"

class Collider : public IPhysicsComponent
{

};
