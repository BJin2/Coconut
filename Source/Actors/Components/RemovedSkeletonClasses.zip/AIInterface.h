#pragma once
#include "ActorComponent.h"

class IAI : public ActorComponent
{

};
