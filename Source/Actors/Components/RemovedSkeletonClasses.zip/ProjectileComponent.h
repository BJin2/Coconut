#pragma once
#include "ActorComponent.h"

class ProjectileComponent : public ActorComponent
{

};
