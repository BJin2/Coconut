#pragma once
#include "Collider.h"

class BoxCollider : public Collider
{

};
