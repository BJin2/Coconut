#pragma once
#include "RendererInterface.h"

class IUI : public IRenderer
{

};
