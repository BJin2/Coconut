#pragma once
#include "ActorComponent.h"

class IPhysicsComponent : public ActorComponent
{

};
