#pragma once
#include "ActorComponent.h"

class CharacterStatComponent : public ActorComponent
{

};
