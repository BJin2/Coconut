#pragma once
#include "UIInterface.h"

class Button : public IUI
{

};
