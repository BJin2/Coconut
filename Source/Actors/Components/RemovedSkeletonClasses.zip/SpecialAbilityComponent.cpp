#include "SpecialAbilityComponent.h"

//Empty function for now
//bool SpecialAbilityComponent::VInit(TiXmlElement* pData)
//{
//	return false;
//}
//Empty function for now
const char* SpecialAbilityComponent::VGetName()
{
	return nullptr;
}
//Empty function for now
void SpecialAbilityComponent::VAbilityAction()
{
}
